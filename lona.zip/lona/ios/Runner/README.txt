После flutter create . откройте ios/Runner.xcworkspace в Xcode, выберите Team и уникальный Bundle Identifier. Разрешение уведомлений приложение запросит само.
