# Калокагатия · 30 дней, версия 1.0

Готовый GitHub-проект офлайн-трекера для Android и iOS. На GitHub Actions автоматически создаётся Android APK и публикуется в Releases.

С телефона начните с файла **ИНСТРУКЦИЯ_С_ТЕЛЕФОНА.md**.


Офлайн-приложение Flutter для Android и iOS. Данные, заметки, замеры и настройки сохраняются локально в Hive. Аккаунт и сервер не нужны.

## Что реализовано
- Экран дня со стрелками, неделей, прогрессом, серией, группами и раскрываемым «Как делать».
- Расписание, сетка 30 дней, замеры с автоматической разницей, настройки старта, темы и трёх напоминаний.
- Прогрессия подходов и повторов по неделям.
- День 29: Агон. Дни 1 и 30: замеры и фото.
- Русский интерфейс, тёмно-синяя и бронзовая тема, крупные зоны нажатия.

## Подготовка проекта
Нужны Flutter 3.38.1 или новее, Android Studio и Android SDK. Для iOS нужен Mac с Xcode.

```bash
unzip kalokagatia_30_days.zip
cd kalokagatia_30_days
flutter create . --platforms=android,ios --org com.example
flutter pub get
```

После `flutter create` снова проверьте `android/app/src/main/AndroidManifest.xml`: в архиве лежит готовый вариант с разрешением уведомлений и receivers. Если команда его заменила, восстановите файл из архива.

## Запуск
```bash
flutter devices
flutter run
```

## APK
```bash
flutter clean
flutter pub get
flutter build apk --release
```
Готовый файл: `build/app/outputs/flutter-apk/app-release.apk`.

Для APK меньшего размера по архитектурам:
```bash
flutter build apk --release --split-per-abi
```

## Установка APK
1. Передайте APK на Android-телефон.
2. Откройте файл и разрешите установку из этого источника, если Android попросит.
3. Установите приложение и разрешите уведомления при первом запуске.

Через ADB:
```bash
adb install -r build/app/outputs/flutter-apk/app-release.apk
```

## iOS
```bash
open ios/Runner.xcworkspace
```
В Xcode выберите `Runner` → `Signing & Capabilities`, укажите Team и уникальный Bundle Identifier, подключите iPhone и нажмите Run. Для публикации используйте Product → Archive.

## Замечания по уведомлениям
Используется неточный ежедневный режим `inexactAllowWhileIdle`, поэтому Android может слегка сдвигать время ради экономии батареи. Это не требует специального доступа к точным будильникам. На iOS и Android пользователь должен разрешить уведомления.

## Проверка
В этой среде Flutter SDK отсутствовал, поэтому проект не был собран здесь. Код и структура подготовлены для стандартной генерации платформенных папок командой `flutter create .`.
