import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:hive_flutter/hive_flutter.dart';
import 'package:intl/intl.dart';
import 'package:intl/date_symbol_data_local.dart';
import 'package:flutter_local_notifications/flutter_local_notifications.dart';
import 'package:timezone/data/latest.dart' as tz;
import 'package:timezone/timezone.dart' as tz;
import 'package:flutter_timezone/flutter_timezone.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await initializeDateFormatting('ru_RU');
  await Hive.initFlutter();
  final box = await Hive.openBox('kalokagatia');
  await Notifications.init();
  runApp(App(box: box));
}

class Exercise {
  final String id, title, unit, how;
  final int sets, reps, step;
  const Exercise(this.id,this.title,this.sets,this.reps,this.step,this.unit,this.how);
  factory Exercise.fromJson(Map<String,dynamic> j)=>Exercise(j['id'],j['title'],j['sets'],j['reps'],j['step'],j['unit'],j['how']);
}
class TaskItem {
  final String id, title, group, how;
  final int? sets, reps;
  final String unit;
  const TaskItem({required this.id,required this.title,required this.group,this.how='',this.sets,this.reps,this.unit=''});
  String get prescription => sets==null?'':(sets==1?'$reps $unit':'$sets×$reps $unit').trim();
}

class Notifications {
  static final plugin=FlutterLocalNotificationsPlugin();
  static Future<void> init() async {
    tz.initializeTimeZones();
    try { final z=await FlutterTimezone.getLocalTimezone(); tz.setLocalLocation(tz.getLocation(z.identifier)); } catch (_) {}
    const init=InitializationSettings(android: AndroidInitializationSettings('@mipmap/ic_launcher'), iOS: DarwinInitializationSettings());
    await plugin.initialize(init);
    await plugin.resolvePlatformSpecificImplementation<AndroidFlutterLocalNotificationsPlugin>()?.requestNotificationsPermission();
    await plugin.resolvePlatformSpecificImplementation<IOSFlutterLocalNotificationsPlugin>()?.requestPermissions(alert:true,badge:true,sound:true);
  }
  static Future<void> schedule(TimeOfDay wake,TimeOfDay train,TimeOfDay sleep) async {
    await plugin.cancelAll();
    const details=NotificationDetails(android:AndroidNotificationDetails('daily','Ежедневные напоминания',channelDescription:'Режим испытания',importance:Importance.high,priority:Priority.high),iOS:DarwinNotificationDetails());
    final rows=[(1,'Подъём','Вода, мобильность, холодный душ',wake),(2,'Тренировка','Время укреплять тело и характер',train),(3,'Сон','Убери экраны и готовься ко сну',sleep)];
    for(final r in rows){final now=tz.TZDateTime.now(tz.local);var at=tz.TZDateTime(tz.local,now.year,now.month,now.day,r.$4.hour,r.$4.minute);if(at.isBefore(now))at=at.add(const Duration(days:1));await plugin.zonedSchedule(r.$1,r.$2,r.$3,at,details,androidScheduleMode:AndroidScheduleMode.inexactAllowWhileIdle,matchDateTimeComponents:DateTimeComponents.time);}
  }
}

class App extends StatefulWidget { final Box box; const App({super.key,required this.box}); @override State<App> createState()=>_AppState(); }
class _AppState extends State<App>{
  late bool dark;
  @override void initState(){super.initState();dark=widget.box.get('dark',defaultValue:true);}
  @override Widget build(BuildContext c)=>MaterialApp(debugShowCheckedModeBanner:false,title:'Калокагатия · 30 дней',themeMode:dark?ThemeMode.dark:ThemeMode.light,theme:theme(false),darkTheme:theme(true),home:Home(box:widget.box,onTheme:(v){widget.box.put('dark',v);setState(()=>dark=v);}));
  ThemeData theme(bool d){const bronze=Color(0xffb88338);final scheme=ColorScheme.fromSeed(seedColor:bronze,brightness:d?Brightness.dark:Brightness.light,surface:d?const Color(0xff132631):const Color(0xfff8f7f2));return ThemeData(colorScheme:scheme,scaffoldBackgroundColor:d?const Color(0xff091922):const Color(0xffeceeea),useMaterial3:true,textTheme:ThemeData(brightness:d?Brightness.dark:Brightness.light).textTheme.apply(fontFamily:'serif'),cardTheme:const CardThemeData(margin:EdgeInsets.symmetric(vertical:6),clipBehavior:Clip.antiAlias));}
}

class Home extends StatefulWidget{final Box box;final ValueChanged<bool> onTheme;const Home({super.key,required this.box,required this.onTheme});@override State<Home> createState()=>_HomeState();}
class _HomeState extends State<Home>{
  int tab=0, selected=0; List<Exercise> exercises=[];
  DateTime get start=>DateTime.parse(widget.box.get('start',defaultValue:DateFormat('yyyy-MM-dd').format(DateTime.now())));
  DateTime dateOf(int i)=>DateTime(start.year,start.month,start.day+i);
  int get todayIndex=>DateTime.now().difference(DateTime(start.year,start.month,start.day)).inDays.clamp(0,29) as int;
  @override void initState(){super.initState();selected=todayIndex;rootBundle.loadString('assets/exercises.json').then((s){exercises=(jsonDecode(s) as List).map((e)=>Exercise.fromJson(e)).toList();setState((){});});}
  Exercise ex(String id)=>exercises.firstWhere((x)=>x.id==id);
  List<TaskItem> tasks(int i){if(exercises.isEmpty)return[];final week=(i~/7+1).clamp(1,4) as int;TaskItem e(String id){final x=ex(id),sets=x.sets+(week>=3&&x.sets>1?1:0),reps=x.reps+x.step*(week-1);return TaskItem(id:'ex_$id',title:x.title,group:'Тренировка',how:x.how,sets:sets,reps:reps,unit:x.unit);}final list=<TaskItem>[
    const TaskItem(id:'wake',title:'Подъём в 4:15 и стакан воды',group:'Утро',how:'Встань без повтора будильника и сразу выпей воду.'),
    const TaskItem(id:'mob',title:'Мобильность 5–10 минут',group:'Утро',how:'Плавно разомни плечи, спину, бёдра и голеностоп без боли.'),
    TaskItem(id:'cold',title:'Холодный душ ${i>=14?'1–2 мин':'30–60 сек'}',group:'Утро',how:'Начни с конечностей, дыши ровно. При недомогании пропусти.'),
    const TaskItem(id:'food',title:'Еда с собой: белок, овощи, гарнир',group:'День',how:'Подготовь контейнер заранее и пей воду.'),
    const TaskItem(id:'clean',title:'Без сладкого, фастфуда и алкоголя',group:'День',how:'При тяге выбери фрукт, несладкий напиток или небольшую порцию орехов.'),
  ];
  if(i==0||i==29)list.add(const TaskItem(id:'measure',title:'Замеры и фото',group:'День',how:'Утром, натощак, в одинаковых условиях.'));
  if(i==28){for(final t in ['Бег 2 км','Подтягивания: максимум','Отжимания: максимум','Приседания с гантелью: максимум','Планка: максимум'])list.add(TaskItem(id:'agon_$t',title:t,group:'Тренировка',how:'Разомнись, выполни безопасно и запиши результат в заметке.'));}
  else {final ids={DateTime.monday:['goblet_squat','floor_press','overhead_press','pushups','plank'],DateTime.tuesday:['pullups','row','rdl','curl','hang'],DateTime.wednesday:['run','leg_raise','twist','side_plank'],DateTime.thursday:['mobility','walk'],DateTime.friday:['swing','pullups','pushups','bulgarian','burpee'],DateTime.saturday:['fast_walk','farmer','stretch'],DateTime.sunday:['contrast','plan_week']}[dateOf(i).weekday]!;list.addAll(ids.map(e));}
  list.addAll(const [TaskItem(id:'read',title:'Чтение 15 минут',group:'Вечер',how:'Выбери одну мысль, которую хочешь запомнить.'),TaskItem(id:'journal',title:'Дневник: 3 строки',group:'Вечер',how:'Что сделал, что понял, что улучшить завтра.'),TaskItem(id:'sleep',title:'Экраны выключены, сон в 21:15',group:'Вечер',how:'Приглуши свет и убери телефон за 30 минут до сна.')]);return list;}
  bool checked(int d,String id)=>widget.box.get('done_${d}_$id',defaultValue:false);
  double fraction(int d){final x=tasks(d);if(x.isEmpty)return 0;return x.where((t)=>checked(d,t.id)).length/x.length;}
  int streak(){var n=0;for(var i=todayIndex;i>=0;i--){if(fraction(i)==1)n++;else break;}return n;}
  @override Widget build(BuildContext c){final pages=[today(),schedule(),grid(),measurements(),settings()];return Scaffold(appBar:AppBar(title:const Text('Калокагатия · 30 дней'),centerTitle:true),body:SafeArea(child:pages[tab]),bottomNavigationBar:NavigationBar(selectedIndex:tab,onDestinationSelected:(i)=>setState(()=>tab=i),destinations:const [NavigationDestination(icon:Icon(Icons.today),label:'Сегодня'),NavigationDestination(icon:Icon(Icons.schedule),label:'График'),NavigationDestination(icon:Icon(Icons.grid_view),label:'30 дней'),NavigationDestination(icon:Icon(Icons.straighten),label:'Замеры'),NavigationDestination(icon:Icon(Icons.settings),label:'Настройки')]));}
  Widget today(){final ts=tasks(selected),done=ts.where((t)=>checked(selected,t.id)).length,d=dateOf(selected),week=(selected~/7+1).clamp(1,4) as int,names=['','Основание','Нагрузка','Закалка','Агон'];return ListView(padding:const EdgeInsets.all(12),children:[Card(child:Padding(padding:const EdgeInsets.all(16),child:Column(children:[Row(mainAxisAlignment:MainAxisAlignment.spaceBetween,children:[IconButton(icon:const Icon(Icons.chevron_left),onPressed:selected>0?()=>setState(()=>selected--):null),Column(children:[Text('День ${selected+1} из 30',style:Theme.of(context).textTheme.headlineSmall),Text('${DateFormat('EEEE, d MMMM','ru_RU').format(d)} · неделя $week «${names[week]}»')]),IconButton(icon:const Icon(Icons.chevron_right),onPressed:selected<29?()=>setState(()=>selected++):null)]),const SizedBox(height:12),LinearProgressIndicator(value:ts.isEmpty?0:done/ts.length,minHeight:10,borderRadius:BorderRadius.circular(8)),const SizedBox(height:8),Text('$done из ${ts.length} · серия ${streak()} дн.')]))),for(final g in ['Утро','День','Тренировка','Вечер'])...[_heading(g),Card(child:Column(children:ts.where((t)=>t.group==g).map((t)=>ExpansionTile(minTileHeight:64,leading:Checkbox(value:checked(selected,t.id),onChanged:(v){widget.box.put('done_${selected}_${t.id}',v);setState((){});}),title:Text(t.title),subtitle:t.prescription.isEmpty?null:Text(t.prescription),children:[Padding(padding:const EdgeInsets.fromLTRB(72,0,18,16),child:Align(alignment:Alignment.centerLeft,child:Text(t.how)))] )).toList()))],_heading('Заметка дня'),Card(child:Padding(padding:const EdgeInsets.all(12),child:TextFormField(initialValue:widget.box.get('note_$selected',defaultValue:''),maxLines:4,decoration:const InputDecoration(hintText:'Результаты, самочувствие, вывод дня',border:OutlineInputBorder()),onChanged:(v)=>widget.box.put('note_$selected',v))))]);}
  Widget _heading(String s)=>Padding(padding:const EdgeInsets.only(top:14,left:4,bottom:4),child:Text(s,style:Theme.of(context).textTheme.titleLarge?.copyWith(color:Theme.of(context).colorScheme.primary)));
  Widget schedule(){final rows=[['04:15','Подъём, вода, мобильность, холодный душ'],['19:15','Тренировка 45–60 минут'],['20:45','Чтение и дневник'],['21:15','Сон']];final week=['Пн · сила','Вт · тяга и спина','Ср · бег и пресс','Чт · лёгкий день','Пт · пятиборье по кругу','Сб · прогулка и выносливость','Вс · отдых'];return ListView(padding:const EdgeInsets.all(12),children:[_heading('Распорядок'),...rows.map((r)=>Card(child:ListTile(leading:Text(r[0],style:const TextStyle(fontWeight:FontWeight.bold)),title:Text(r[1])))),_heading('Неделя'),...week.map((x)=>Card(child:ListTile(title:Text(x))))]);}
  Widget grid(){return GridView.builder(padding:const EdgeInsets.all(16),gridDelegate:const SliverGridDelegateWithFixedCrossAxisCount(crossAxisCount:5,crossAxisSpacing:8,mainAxisSpacing:8),itemCount:30,itemBuilder:(c,i){final f=fraction(i),color=f==1?Colors.green:f>0?Colors.lightGreen.shade200:null;return FilledButton(style:FilledButton.styleFrom(backgroundColor:color,foregroundColor:f>0?Colors.black:null,shape:RoundedRectangleBorder(borderRadius:BorderRadius.circular(12),side:i==todayIndex?BorderSide(color:Theme.of(c).colorScheme.primary,width:3):BorderSide.none)),onPressed:(){setState((){selected=i;tab=0;});},child:Text('${i+1}'));});}
  Widget measurements(){final fields={'weight':'Вес, кг','waist':'Талия, см','chest':'Грудь, см','arm':'Рука, см','pullups':'Подтягивания','pushups':'Отжимания','run2k':'Бег 2 км, сек'};return ListView(padding:const EdgeInsets.all(12),children:[_heading('День 1 и день 30'),...fields.entries.map((e)=>Card(child:Padding(padding:const EdgeInsets.all(12),child:Column(crossAxisAlignment:CrossAxisAlignment.start,children:[Text(e.value,style:Theme.of(context).textTheme.titleMedium),Row(children:[Expanded(child:_number('${e.key}_1','День 1')),const SizedBox(width:8),Expanded(child:_number('${e.key}_30','День 30'))]),Builder(builder:(c){final a=double.tryParse(widget.box.get('${e.key}_1',defaultValue:'')),b=double.tryParse(widget.box.get('${e.key}_30',defaultValue:''));return a!=null&&b!=null?Padding(padding:const EdgeInsets.only(top:8),child:Text('Разница: ${(b-a).toStringAsFixed(1)}')):const SizedBox();})])))]);}
  Widget _number(String key,String label)=>TextFormField(initialValue:widget.box.get(key,defaultValue:''),keyboardType:const TextInputType.numberWithOptions(decimal:true),decoration:InputDecoration(labelText:label),onChanged:(v){widget.box.put(key,v);setState((){});});
  TimeOfDay _time(String key,String fallback){final s=widget.box.get(key,defaultValue:fallback) as String,p=s.split(':');return TimeOfDay(hour:int.parse(p[0]),minute:int.parse(p[1]));}
  Widget settings(){final isDark=widget.box.get('dark',defaultValue:true) as bool;Future<void> pick(String key,String fallback)async{final x=await showTimePicker(context:context,initialTime:_time(key,fallback));if(x!=null){widget.box.put(key,'${x.hour.toString().padLeft(2,'0')}:${x.minute.toString().padLeft(2,'0')}');await Notifications.schedule(_time('wake','04:15'),_time('train','19:15'),_time('sleep','21:15'));setState((){});}}return ListView(padding:const EdgeInsets.all(12),children:[Card(child:ListTile(title:const Text('Дата старта'),subtitle:Text(DateFormat('d MMMM yyyy','ru_RU').format(start)),trailing:const Icon(Icons.calendar_month),onTap:()async{final d=await showDatePicker(context:context,firstDate:DateTime(2020),lastDate:DateTime(2100),initialDate:start);if(d!=null){widget.box.put('start',DateFormat('yyyy-MM-dd').format(d));setState(()=>selected=todayIndex);}})),for(final x in [('wake','04:15','Подъём'),('train','19:15','Тренировка'),('sleep','21:15','Сон')])Card(child:ListTile(title:Text(x.$3),subtitle:Text(_time(x.$1,x.$2).format(context)),trailing:const Icon(Icons.notifications),onTap:()=>pick(x.$1,x.$2))),Card(child:SwitchListTile(title:const Text('Тёмная тема'),value:isDark,onChanged:widget.onTheme)),Padding(padding:const EdgeInsets.all(8),child:FilledButton.icon(onPressed:()async{await Notifications.schedule(_time('wake','04:15'),_time('train','19:15'),_time('sleep','21:15'));if(mounted)ScaffoldMessenger.of(context).showSnackBar(const SnackBar(content:Text('Напоминания обновлены')));},icon:const Icon(Icons.alarm),label:const Text('Обновить напоминания')))]);}
}
